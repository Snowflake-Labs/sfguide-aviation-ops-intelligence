import{K as i}from"./index.SZN76Czo.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
